package com.purna.hostel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HostelBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
